package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/**
 * Procedural cosmetics for players: smooth membrane wings with feather veins,
 * a glow halo and a cape. No textures needed, so the shapes stay smooth at any size.
 *
 * Coordinates are in player model space: y is negative upward, +z is behind the player.
 */
public class CosmeticsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    /** Wing palettes by style index; index 0 follows the theme accent. */
    private static final int[] WING_PALETTE = {
            0,          // theme accent (filled at runtime)
            0xFFFF4D6D, // demon
            0xFF2B2D42, // dark
            0xFF8ECAE6, // crystal
            0xFF80FFDB  // energy
    };

    public CosmeticsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!Config.master || player.isInvisible()) return;

        Minecraft mc = Minecraft.getInstance();
        boolean self = player == mc.player;
        if (!self) {
            if (!Config.others) return;
            if (mc.player != null
                    && player.distanceToSqr(mc.player) > Config.maxDistance * Config.maxDistance) return;
        }

        boolean perf = Config.autoPerf && !self;
        float size = (float) (Config.scale * Config.wingSize);
        float dy = player.isCrouching() ? 0.2f : 0f;
        int accent = Config.color() | 0xFF000000;

        Matrix4f m = pose.last().pose();
        VertexConsumer vc = buffers.getBuffer(RenderType.lightning());

        if (Config.cape) {
            cape(vc, m, ageInTicks, limbSwingAmount, dy, accent);
        }
        if (Config.halo) {
            halo(vc, m, ageInTicks, dy, accent, perf ? 18 : 36);
        }
        if (Config.wings) {
            int style = Mth.clamp(Config.wingStyle, 0, WING_PALETTE.length - 1);
            int base = style == 0 ? accent : WING_PALETTE[style];

            float phase = ageInTicks * 0.12f + limbSwing * 0.6f;
            float amp = 0.3f + 0.4f * limbSwingAmount + (player.onGround() ? 0f : 0.4f);
            float flap = Mth.clamp((float) Math.sin(phase) * amp, -1f, 1f);

            int feathers = perf ? 6 : 10;
            for (int side = -1; side <= 1; side += 2) {
                // soft outer glow first, then the membrane on top
                wing(vc, m, side, flap, feathers, size * 1.12f, dy, withA(base, 60), withA(base, 0), true);
                wing(vc, m, side, flap, feathers, size, dy, withA(base, 200), withA(base, 35), false);
            }
        }
    }

    // ---------- wings ----------

    private static void wing(VertexConsumer vc, Matrix4f m, int side, float flap, int feathers, float scale,
                             float dy, int rootColor, int tipColor, boolean glowPass) {
        float rootX = side * 0.22f;
        float rootY = -1.35f + dy;
        float rootZ = 0.08f;

        float[][] tips = new float[feathers][3];
        for (int i = 0; i < feathers; i++) {
            float t = i / (float) (feathers - 1);
            // sweep from pointing outward (-0.15 rad) to pointing back (~1.9 rad), flap bends it
            float ang = Mth.lerp(t, -0.15f, 1.9f) + flap * 0.35f * (0.4f + t);
            float len = scale * 0.8f * (0.95f + 0.55f * (float) Math.sin(Math.PI * (0.25 + 0.6 * t)))
                    * (1f + 0.12f * flap) * (1f - 0.25f * t);
            tips[i][0] = rootX + side * (float) Math.cos(ang) * len;
            tips[i][1] = rootY + (float) Math.sin(ang) * len * 0.25f + t * 0.1f * len;
            tips[i][2] = rootZ + (float) Math.sin(ang) * len;
        }

        float[] root = {rootX, rootY, rootZ};
        for (int i = 0; i < feathers - 1; i++) {
            tri(vc, m, root, tips[i], tips[i + 1], rootColor, tipColor, tipColor);
        }

        if (!glowPass) {
            // bright vein per feather, thin triangle from the root to the tip
            int vein = withA(0xFFFFFF, 90);
            for (float[] tip : tips) {
                float[] tipLift = {tip[0], tip[1] + 0.012f, tip[2]};
                tri(vc, m, root, tip, tipLift, vein, vein, vein);
            }
        }
    }

    // ---------- halo ----------

    private static void halo(VertexConsumer vc, Matrix4f m, float ageInTicks, float dy, int color, int segments) {
        float y = -2.15f + dy;
        float inner = 0.26f;
        float outer = 0.34f;
        float spin = ageInTicks * 0.04f;
        int innerCol = withA(color, 220);
        int outerCol = withA(color, 30);
        for (int j = 0; j < segments; j++) {
            float a0 = (float) (Math.PI * 2 * j / segments) + spin;
            float a1 = (float) (Math.PI * 2 * (j + 1) / segments) + spin;
            float[] i0 = {(float) Math.cos(a0) * inner, y, (float) Math.sin(a0) * inner};
            float[] i1 = {(float) Math.cos(a1) * inner, y, (float) Math.sin(a1) * inner};
            float[] o0 = {(float) Math.cos(a0) * outer, y, (float) Math.sin(a0) * outer};
            float[] o1 = {(float) Math.cos(a1) * outer, y, (float) Math.sin(a1) * outer};
            tri(vc, m, i0, o0, o1, innerCol, outerCol, outerCol);
            tri(vc, m, i0, o1, i1, innerCol, outerCol, innerCol);
        }
    }

    // ---------- cape ----------

    private static void cape(VertexConsumer vc, Matrix4f m, float ageInTicks, float limbSwingAmount,
                             float dy, int color) {
        float sway = (float) Math.sin(ageInTicks * 0.1f) * 0.04f + limbSwingAmount * 0.08f;
        float topY = -1.4f + dy;
        float botY = -0.2f + dy;
        float z0 = 0.12f;
        float z1 = 0.28f + sway;
        float[] tl = {-0.25f, topY, z0};
        float[] tr = {0.25f, topY, z0};
        float[] bl = {-0.3f + sway, botY, z1};
        float[] br = {0.3f + sway, botY, z1};
        int top = withA(color, 230);
        int bottom = withA(color, 50);
        tri(vc, m, tl, tr, bl, top, top, bottom);
        tri(vc, m, tr, br, bl, top, bottom, bottom);
    }

    // ---------- helpers ----------

    private static int withA(int argb, int a) {
        return (Mth.clamp(a, 0, 255) << 24) | (argb & 0xFFFFFF);
    }

    /** Emits one triangle, twice (front and back) so it stays visible from both sides. */
    private static void tri(VertexConsumer vc, Matrix4f m, float[] a, float[] b, float[] c,
                            int ca, int cb, int cc) {
        vc.addVertex(m, a[0], a[1], a[2]).setColor(ca);
        vc.addVertex(m, b[0], b[1], b[2]).setColor(cb);
        vc.addVertex(m, c[0], c[1], c[2]).setColor(cc);
        vc.addVertex(m, c[0], c[1], c[2]).setColor(cc);
        vc.addVertex(m, b[0], b[1], b[2]).setColor(cb);
        vc.addVertex(m, a[0], a[1], a[2]).setColor(ca);
    }
}
